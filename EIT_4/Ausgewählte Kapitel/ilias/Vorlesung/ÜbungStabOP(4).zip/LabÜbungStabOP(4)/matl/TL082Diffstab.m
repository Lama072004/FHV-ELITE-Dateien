%Diff nicht stab; TL082cp
clear;close all;
R=10e3;
C=0.1e-6;
%Stab Wid, TP-Knick bei:
wt=2.15e5;
%wt=1/(Rstab*C) => Rstab= 1/(wt*C)
Rstab= 1/(wt*C)

A0= 0.7*10^6;
w1=10*2*pi;
w2=25e6 *2*pi;
w3=30e6 *2*pi;
s=tf('s');
A=A0/((1+s/w1)*(1+s/w2)*(1+s/w3));
figure(1);
subplot(1,2,1);bode(A,{10,10^8})

wk=1/(R*C);
K=(Rstab+1/(s*C))/R;;EinsdurchK=1/K;
hold on; bode(EinsdurchK);grid;

T=A/(1+A*K);
bode(T);legend; title('A, 1/K und T')

L=A*K;
subplot(1,2,2); bode(L,{10,10^8}); grid; legend;title('L');

%Zeitbereich
%ue= 1kHz Dreieck mit 1V Amplitude
Tper=1/1000;Ta=1e-6; tend=2*Tper;t=[Ta:Ta:tend];
ue=[Ta:Ta:Tper/2]*2/(Tper/2)-1;
ue=[ue -ue];
ue=[ue ue];
ua= lsim(T,ue,t);
figure(2), 
subplot(2,1,1);plot(t,ue);hold on;
subplot(2,1,2);plot(t,ua);grid,legend;title('ue, ua(t)')
hold off