% Erzeugung Messdaten Kreis
radius=3; %just an example
theta=linspace(0,2*pi,200);
xdata=(radius+0.1*rand())*cos(theta)+4;
ydata=(radius+0.2*rand())*sin(theta)+2;
% Fit mit Kreis
% (x?xo)^2+(y?yo)^2=r^2
% x^2?2xxo+xo^2+y^2?2yyo+yo^2=r^2
% 2xxo+2yyo+r^2=x^2+y^2
% [2x 2y 1]*[xo;yo;xo^2+yo^2+r^2]=[x^2+y^2]
% A*x=B
A = [2*xdata(:) 2*ydata(:) ones(length(xdata(:)),1)];
B = (xdata(:).^2+ydata(:).^2);
x = A\B;
xo=x(1);
yo=x(2);
R = sqrt(xo.^2 + yo.^2 + x(3));
x=R*cos(theta)+xo;
y=R*sin(theta)+yo;
plot(xdata,ydata,'x',x,y);