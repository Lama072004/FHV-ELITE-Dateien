% Datenwerte
in=[
6.99 4.202;
10.25 4.184;
25.00 4.170;
29.03 4.173;
41.40 4.173;
49.73 4.173;
53.23 4.177;
64.52 4.187;
70.97 4.189;
95.70 4.209;
];
% Vektorextraktion aus Datensatz IN
t = in(:,1);
cp = in(:,2);
t1 = 15; % Temperatur der gesuchten W�rmekapazit�t
tI = min(t)-0.3:0.1:max(t)+0.3; % Werte zum Plotten
% Polynom
poly = polyfit(t, cp, length(t)-4);
cpP = polyval(poly, tI);
% Plot
plot(t, cp, 'k*', tI, cpP, 'b-')
ylim([4.16 4.29]);
xlabel('t [Celsius]');
ylabel('c_p [kJ/(kg K)]');
legend('Messpunkte', 'linear', 'Spline', 'Polynom', 'Location','NorthWest');