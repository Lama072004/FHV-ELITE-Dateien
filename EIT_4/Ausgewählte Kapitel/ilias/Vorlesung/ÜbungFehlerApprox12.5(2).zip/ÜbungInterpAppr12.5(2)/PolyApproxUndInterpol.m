%Polynominterpolation: Ordnung des Polynoms steigt bei vielen Messdaten 
% und neigt deshalb zum Schwingen!
% besser: Polynomapproximation niedriger Ordnung

%kubisches Polynom approximierend einpassen
clear; close all

%fehlerbehaftete Messdaten erzeugen

x=linspace(-1,4,100);
y=2+1.3*x+1.5*x.*x;
figure(1);plot(x,y,'bl');hold on
xi=[-1 0 2 3 4];
y=2+1.3*xi+1.5*xi.*xi;
y(4)=y(4)-10;                   %Fehler hinzu
yi=y+5*(rand(1,length(xi))-0.5);%Fehler hinzu
figure(1);plot(xi,yi,'r*');

%interpol vandermonde 5Messwerte => Ordnung Vandermonde 5! statt x^2

% Vandermondematrix bestimmen 
A=fliplr(vander(xi));
% Bestimmen der Koeffizienten a_i
ai=inv(A)*yi';
% f�r die Ausgabe Datensatz erstellen aus Polynom
y=polyval(fliplr(ai'),x);
% Plot
figure(1);plot(x,y,'.b');

%Approx poly 2ter O.!
% Vandermondematrix bestimmen 
A=A(:,1:3); %sodass ein Polynom 2ter Ordnung (bisx^2) opt eingepasst wird
% Bestimmen der Koeffizienten a_i
ai_=A\yi';
% f�r die Ausgabe Datensatz erstellen aus Polynom
y=polyval(fliplr(ai_'),x);
% Plot
figure(1);plot(x,y,'.y');
title('blau ideal, rot mit Messfehlern, bl: Vandermonde(intperpol), y:kubisch(approx) ')
