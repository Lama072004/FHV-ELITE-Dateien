clear all;
close all;
% Messwerte
xi = [1, 2, 3, 4, 5];
yi = [1, 2,1, 1, 4];
plot(xi,yi,'ro');
hold on;
% Vandermondematrix bestimmen
A=fliplr(vander(xi));
% Bestimmen der Koeffizienten a_i
ai=inv(A)*yi';
% Datensatz erstellen aus Polynom
x=linspace(1,5,100);
y=polyval(fliplr(ai'),x);
% Plot
plot(x,y);
grid on;
title('Polynominterpolation');
xlabel('x?Werte');
ylabel('y?Werte');