clear;close all;
%Kreisapprox 10 Messpunkte => überbestimmt, dh Kreis-Approx nötig
%Matlab wechselt beim Invertieren automatisch zur Approx, wenn
%überbestimmtes (=rechteckige A-Matrix) vorliegt
radius=3; %just an example
theta=linspace(0,2*pi,10);
xdata=(radius+0.2*rand())*cos(theta)+4;
ydata=(radius+0.3*rand())*sin(theta)+2;
% Fit mit Kreis
% (x−xo)^2+(y−yo)^2=r^2
% x^2−2xxo+xo^2+y^2−2yyo+yo^2=r^2
% 2xxo+2yyo+r^2=x^2+y^2
% [2x 2y 1]*[xo;yo;xo^2+yo^2+r^2]=[x^2+y^2]
% A*x=B
A = [2*xdata(:) 2*ydata(:) ones(length(xdata(:)),1)];
B = (xdata(:).^2+ydata(:).^2);
x = A\B;%überbestimmtes Gleichungssystem, A rechteckig, Matlab approx!
xo=x(1);
yo=x(2);
R = sqrt(xo.^2 + yo.^2 + x(3));
theta=linspace(0,2*pi,200);
x=R*cos(theta)+xo;
y=R*sin(theta)+yo;
subplot(1,2,1);plot(xdata,ydata,'x',x,y);title('10Messpu Kreis Approx')

%nun drei (hoffentlich genaue) Messpunkte => Kreisinterpolation statt
%Approx, nun eine quadratische Matrix, normal invertierbar, keine Approx
radius=3; %just an example
theta=linspace(0,2*pi*0.8,3);
xdata=(radius+0.2*rand())*cos(theta)+4;%Messung leider nicht sehr genau
ydata=(radius+0.3*rand())*sin(theta)+2;%Messung leider nicht sehr genau
% Fit mit Kreis
% (x−xo)^2+(y−yo)^2=r^2
% x^2−2xxo+xo^2+y^2−2yyo+yo^2=r^2
% 2xxo+2yyo+r^2=x^2+y^2
% [2x 2y 1]*[xo;yo;xo^2+yo^2+r^2]=[x^2+y^2]
% A*x=B
A = [2*xdata(:) 2*ydata(:) ones(length(xdata(:)),1)];
B = (xdata(:).^2+ydata(:).^2);
x = A\B; %A quadratisch, exakt bestimmtes GLeichungssystem, Interpolation!
xo=x(1);
yo=x(2);
R = sqrt(xo.^2 + yo.^2 + x(3));
theta=linspace(0,2*pi,200);
x=R*cos(theta)+xo;
y=R*sin(theta)+yo;
subplot(1,2,2);plot(xdata,ydata,'x',x,y);title('3Messpu Kreis Interpol')



