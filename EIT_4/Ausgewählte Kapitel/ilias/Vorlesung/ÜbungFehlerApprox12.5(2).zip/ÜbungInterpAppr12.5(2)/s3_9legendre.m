% x0: Eingangsvektor
% y0: Ausgangsvektor
% x: x?Wert, f�r den der y?Wert bestimmt werden soll
% y: y?Wert als Ausgabe
clear all;
% Messpunkte
x0=[6.98, 10.25, 25, 29.03, 41.4, 49.73, 53.23, 64.52, 70.97,95.7];
y0=[4.202, 4.184, 4.17, 4.173, 4.173, 4.173, 4.177, 4.187,4.189, 4.209];
n=size(x0,2);
y=0;
x=linspace(7,100,100);
for i=1:n
term=1;
for k=1:n
if ~isequal(k,i)
term=term.*(x-x0(k))/(x0(i)-x0(k));
end
end
y=y+y0(i)*term;
end
plot(x0,y0,'r*',x,y,'bl');
legend('Data','Lagrange?Fit');
grid on
xlabel('x');
ylabel('y');
