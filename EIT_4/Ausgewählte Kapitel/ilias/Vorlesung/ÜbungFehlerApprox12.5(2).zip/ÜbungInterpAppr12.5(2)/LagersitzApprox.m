%clear
%MessdatenSim
r=1;%radius
phi=[0:10:350]*pi/180;
n=length(phi);
al=2*pi/180;be=1*pi/180;                        %Schraeglage des Lagers
x=r*cos(phi); y=r*sin(phi);
hi=r*cos(phi)*sin(al)+r*sin(phi)*sin(be);      %Messung ohne Messfehler
herri=hi+0.01*(rand(1,n)-0.5)+0.01*sin(3*phi);  %Messdaten mit Messfehler
                                                %enth�lt niederfreq
                                                %Fehler!

%sum Fehlerquadrate (h�ndisch durchzuf�hren) f�hrt zu folgendem GLSystem:
%|Sum(herri*cos|/r =|sum(cos^2)     -sum(cos * sin) | * |sin(alpha)|
%|Sum(herri*sin|   =|sum(cos * sin) -sum(sin^2)     |   |sin(beta) |
%    b             =            A                     *     x
%
%
hicosi=mean(herri.*cos(phi))/r;    %b
hisini=mean(herri.*sin(phi))/r;    %b
cos2i=mean(cos(phi).^2);            %A
sin2i=mean(sin(phi).^2);            %A
cosisini=mean(cos(phi).*sin(phi));  %A
A=[cos2i    cosisini
   cosisini sin2i];
b=[hicosi
   hisini];
al_be=inv(A)*b*180/pi
plot3(x,y,herri)
hold on
plot3(x,y,hi)
hold off


