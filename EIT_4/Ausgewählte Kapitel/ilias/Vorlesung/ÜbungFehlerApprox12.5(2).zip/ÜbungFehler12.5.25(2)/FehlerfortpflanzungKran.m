clear
syms Fkml FL alpha L5 r FAU FL2 FL3 
r=1; L5=10.0; 
%abs Fehler der Sensoren:
F_WiSens=1/57;F_FSens=10*200e3*0.2/100; 
%Auslegergewicht=3t 
FAU=10*3e3; 

%sei FL 100t Nennlast zum Test
FL=10*100e3; 
alpha=1; 
%Kraftmesslaschenkraft 200t KML 
Fkml=solve(FL*23*cos(alpha)==12*Fkml*sin(alpha-atan((12*sin(alpha)-r)/(12*cos(alpha)+14)))-FAU*cos(alpha)*L5,Fkml); 
Fkmlnenn=double(Fkml) %Umrechnung in double (Fliesskommazahl) 

%R�ckrechnung zum Test
clear FL 
syms FL 
FL=solve(FL*23*cos(alpha)==12*Fkml*sin(alpha-atan((12*sin(alpha)-r)/(12*cos(alpha)+14)))-FAU*cos(alpha)*L5,FL); 
FLnenn=double(FL) %Umrechnung in double (Fliesskommazahl) 

%Fehlerfortpflanzung:
%zuerst bestimmung von FL(alpha,Fkml)  Ausgangssignal = f(Eingangssignale alpha und 
%Fkml) 
clear Fkml alpha FL 
syms Fkml alpha FL 
FL=solve(FL*23*cos(alpha)==12*Fkml*sin(alpha-atan((12*sin(alpha)-r)/(12*cos(alpha)+14)))-FAU*cos(alpha)*L5,FL) 

%Bildung des totalen Differentials dFL = [dFL/dalpha]*Error_alpha + [dFL/dFkml]*Er
%ror_Fkml 
% [dFL/dalpha]  = sensitivit�t aufgrund Fehler in Alpha 
syms dFL_nach_dalpha 
dFL_nach_dalpha=diff(FL,alpha)
%  
%[dFL/dFkml] = Sensititivit�t aufgrund Fehler in kml 
syms dFL_nach_dkml  
dFL_nach_kmkl=diff(FL,Fkml)

%Messpunkt  bei alph=1 (57�), Kraftmessla Nennlast FKMLnenn einsetzen 
%bei anderen Winkeln  sollte auch gemessen werden! Dann sollte aber FL angepa�t werden  
alph=1; 
dFLaufgrund_Falpha=subs(dFL_nach_dalpha,[alpha Fkml],[alph Fkmlnenn])*F_WiSens; %in Newton 
fr_aufgrund_AlphaFehler_inProz_vonFLnenn =double(dFLaufgrund_Falpha)*100/FLnenn % fr-Fehler Ausgabe in double 

%Fehler aufgrund kml 
dFLaufgrund_Fkml=subs(dFL_nach_kmkl,[alpha Fkml],[alph Fkmlnenn])*F_FSens; 
%Ausgabe in double 
%in Newton 
fr_aufgrund_KMLFehler_inProz_vonFLnenn=double(dFLaufgrund_Fkml)*100/FLnenn 

%=> es sollte ein pr�ziserer Winkelsensor gew�hlt werden, weil die Lastberech
%nung/Lastanzeige stark vom Winkelfehler beeinflusst wird 4.3% statt von KML mit nur 
%0.2% 