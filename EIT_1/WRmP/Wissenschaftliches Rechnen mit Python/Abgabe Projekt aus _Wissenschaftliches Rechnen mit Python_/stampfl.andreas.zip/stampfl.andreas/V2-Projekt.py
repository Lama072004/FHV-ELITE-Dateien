
import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import butter, lfilter, freqz

# Erstellen das Butterworth Filters
def butter_filter(filter_type, cutoff, fs, order=5):
    """
    Erstellt die Koeffizienten eines Butterworth-Filters.

    filter_type       Typ des Filters ('low' oder 'high')
    cutoff            Grenzfrequenz des Filters (in Hz)
    fs                Abtastrate des Signals (in Hz)
    order             Ordnung des Filters
    return            Filterkoeffizienten b, a
    """
    nyquist = 0.5 * fs  # Nyquist Frequenz 0.5 ist in dem fall die Dopplete frequenz
    normalized_cutoff = cutoff / nyquist  # Filter brauchen eine "Normalisierte" Grenzfrequenz (erklärung heraussuchen!)
    # muss zwischen 0 und 1 liegen | 1 entspricht der nyquist frequenz
    # die Cutoff frequnz ist sozusagen die fg (grenzfrequenz)
    b, a = butter(order, normalized_cutoff, btype=filter_type, analog=False)
    return b, a

    # Verwendet: https://www.youtube.com/watch?v=3hGXFdyzoSo        https://www.youtube.com/watch?v=YtP8iwvFBSs

# Anwenden des Filters auf ein Signal
def apply_filter(data, b, a):
    """
    Wendet einen Filter auf ein Signal an.

    data            Eingabesignal
    b               Filterkoeffizienten b
    a               Filterkoeffizienten a
    return          Gefiltertes Signal
    """
    return lfilter(b, a, data)

    # Verwendet: https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.lfilter.html

# Hilfsfunktion: Frequenzgang plotten
def plot_frequency_response(b, a, fs, title):
    """
    Plottet den Frequenzgang eines Filters.

    b      Filterkoeffizienten b
    a      Filterkoeffizienten a
    fs     Abtastrate des Signals (in Hz)
    title  Titel des Plots
    """
    w, h = freqz(b, a, worN=8000)   # worN Die Anzahl der zu berechnenden Punkte
    freq = (fs * 0.5 / np.pi) * w   # Frequenzachse in Hz
    plt.plot(freq, 20 * np.log10(abs(h)), label=title) # logaritmischer maßstab
    plt.title('Frequenzgang')
    plt.xlabel('Frequenz (Hz)')
    plt.ylabel('Amplitude (dB)')
    plt.grid()

# Simulation und Visualisierung
def main():

    # Parameter für Signal und Filtereinstellungen
    fs = 500  # Abtastrate in Hz
    t = np.linspace(0, 2, 2 * fs, endpoint=False)  # Vektor 2 Sekunden | Anzahl der Punkte
    freq_signal = 5  # Frequenz des Nutzsignals
    freq_noise = 50  # Frequenz des Rauschens

    # Erstellen des Signals --> Sinus + Rauschen
    signal = np.sin(2 * np.pi * freq_signal * t)  # Nutzsignal
    noise = 0.5 * np.sin(2 * np.pi * freq_noise * t)  # Störsignal
    noisy_signal = signal + noise  # Verrauschtes Signal

    # Filtereinstellungen
    cutoff_low = 10  # Grenzfrequenz für Tiefpass in Hz
    cutoff_high = 10  # Grenzfrequenz für Hochpasss in Hz
    order = 4  # Ordnung des Filters

    # Tiefpassfilter erstellen
    b_low, a_low = butter_filter('low', cutoff_low, fs, order)
    lowpass_signal = apply_filter(noisy_signal, b_low, a_low)

    # Hochpassfilter erstellen
    b_high, a_high = butter_filter('high', cutoff_high, fs, order)
    highpass_signal = apply_filter(noisy_signal, b_high, a_high)

    # Visualisierung
    plt.figure(figsize=(12, 14))  # Höhe und Breite des Plots definieren

    # Originales verrauschtes Signal
    plt.subplot(5, 1, 1)
    plt.plot(t, noisy_signal, label='Verrauschtes Signal')
    plt.plot(t, signal, label='Originales Nutzsignal', linestyle='--')
    plt.title('Originales und verrauschtes Signal')
    plt.xlabel('Zeit (s)')
    plt.ylabel('Amplitude')
    plt.legend()
    plt.grid()

    # Tiefpassgefiltertes Signal
    plt.subplot(5, 1, 2)
    plt.plot(t, lowpass_signal, label='Tiefpass-gefiltertes Signal', color='green')
    plt.title('Tiefpassfilter - Zeitbereich')
    plt.xlabel('Zeit (s)')
    plt.ylabel('Amplitude')
    plt.legend()
    plt.grid()

    # Hochpassgefiltertes Signal
    plt.subplot(5, 1, 3)
    plt.plot(t, highpass_signal, label='Hochpass-gefiltertes Signal', color='red')
    plt.title('Hochpassfilter - Zeitbereich')
    plt.xlabel('Zeit (s)')
    plt.ylabel('Amplitude')
    plt.legend()
    plt.grid()


    # Frequenzbereich --> Tiefpass gefiltertes Signal
    plt.subplot(5, 1, 4)
    lowpass_fft = np.fft.fft(lowpass_signal)  # fast fourje Transformation | zum Abtasten
    freqs = np.fft.fftfreq(len(lowpass_fft), 1 / fs)
    lowpass_magnitude = np.abs(lowpass_fft) / len(lowpass_fft)
    # Array das die Frequenzwerte enthält //2 (Gazzahldivision) nimmt davon die Hälfte der Werte, somit die Hälfte der Länge übergeben
    plt.plot(freqs[:len(freqs)//2], lowpass_magnitude[:len(freqs)//2], label='Tiefpass - Frequenzbereich', color='green')
    plt.title('Tiefpassfilter - Frequenzbereich')
    plt.xlabel('Frequenz (Hz)')
    plt.ylabel('Amplitude')
    plt.legend()
    plt.grid()

    # Frequenzbereich --> Hochpass gefiltertes Signal
    plt.subplot(5, 1, 5)
    highpass_fft = np.fft.fft(highpass_signal)
    highpass_magnitude = np.abs(highpass_fft) / len(highpass_fft)
    plt.plot(freqs[:len(freqs)//2], highpass_magnitude[:len(freqs)//2], label='Hochpass - Frequenzbereich', color='red') 
    plt.title('Hochpassfilter - Frequenzbereich')
    plt.xlabel('Frequenz (Hz)')
    plt.ylabel('Amplitude')
    plt.legend()
    plt.grid()

    # Diagramm anzeigen
    plt.tight_layout()  # Für bessere Lesbarkeit
    plt.show()

# Programm starten
if __name__ == "__main__":
    main()