"""
    Projekt: Roboter Bahn - Soll/Ist Visualisierung
    -   Skript zum lesen von KUKA Programmen und 
        übersetzten/portieren in csv für die Visualisierung
        mit Matplotlib 

    -   kukaFileToCsv erwartet den Pfad zu einem KUKA Programm und 
        gibt den Pfad zur CSV zurück, alternativ kann über getData das 
        Pandas DataFrame direkt aus der Classe gezogen werden
    
    -   getData gibt nach dem Auslesen eines KUKA Programmes die Daten als
        Pandas.DataFrame zurück 
        

    Ersteller: Böckle Markus
    Erstellt am 08.01.2025 - Aufwand ca. 5Std

    Geändert am xx.xx.xxxx - Aufwand ca. xxStd
"""
import os
import pandas as pd

class ConvertKUKAPrg:
    def __init__(self):
        self.__df = None
        pass
    def getData(self):
        if isinstance(self.__df,pd.DataFrame):
            return self.__df
    def kukaFileToCsv(self, dir=r"Test_Dateien\Feld_Daten\Bauteil_Korea_179\display_17_neu.src"):
        src_file = os.path.join(dir)
        file, _ = os.path.splitext(dir)
        dat_file= os.path.join(file +".dat")
        dat_data = self._extractFromDatFile(dir=dat_file)
        src_data = self._extractFromSrcFile(dir=src_file)
        self.__df = self._connectSrcDatData(src_data=src_data, dat_data=dat_data)
        csv_file= os.path.join(file +".csv")
        self._dftoCsv(dir=csv_file)
        return csv_file
    
    def _dftoCsv(self, dir):
        self.__df.to_csv(dir,header=True, encoding = 'utf8', index=False)
        return

    def _connectSrcDatData(self, src_data, dat_data):
        df_list = []
        for i in src_data:
            data_dict = {}
            if "MoveType" in i:
                data_dict["X"] = dat_data[i["Point"]]["X"]
                data_dict["Y"] = dat_data[i["Point"]]["Y"]
                data_dict["Z"] = dat_data[i["Point"]]["Z"]
                data_dict["A"] = dat_data[i["Point"]]["A"]
                data_dict["B"] = dat_data[i["Point"]]["B"]
                data_dict["C"] = dat_data[i["Point"]]["C"]
                data_dict["speed_c"] = dat_data[i["MoveData"]]["VEL"]
                data_dict["ueb_dis"] = dat_data[i["MoveData"]]["APO_DIST"]
            else:
                data_dict["X"] = i["X"]
                data_dict["Y"] = i["Y"]
                data_dict["Z"] = i["Z"]
                data_dict["A"] = i["A"]
                data_dict["B"] = i["B"]
                data_dict["C"] = i["C"]
                data_dict["speed_c"] = i["speed"]
                data_dict["ueb_dis"] = i["ueb_dis"]
            if len(data_dict)!=0:
                df_list.append(data_dict)
        columns = ["X","Y","Z","A","B","C","speed_c","ueb_dis"]
        df = pd.DataFrame(df_list,columns=columns)
        return df
    def _extractFromDatFile(self, dir):
        f = open(dir)
        lines = f.readlines()
        f.close()
        move_params = {}
        for i in lines:
            if "DECL E6POS" in i:
                poses = {}
                _ , point = i.split("=")[0].split("X")
                pos = i.split("=")
                pos = self._extractFromStr(pos[1],start="{", end="S")
                pos = pos[:-1]
                pos = pos.replace(" ,",",").replace(", ",",").replace(" ",":").split(",")
                for i in pos:
                    a,b = i.split(":")
                    poses[a] = float(b)
                move_params[point] = poses
            if "DECL PDAT" in i:
                datno = i.split("=")[0].replace(" ","")[9:]
                velacc = self._extractFromStr(str=i.split("=")[1], start="{", end="#").replace(" ",":").split(",")
                dats = {}
                for x in range(0,3,2):
                    a,b = velacc[x].split(":")
                    dats[a] = b
                move_params[datno] = dats

            if "DECL LDAT" in i:
                datno = i.split("=")[0].replace(" ","")[9:]
                velacc = self._extractFromStr(str=i.split("=")[1], start="{", end="#").replace(" ",":").split(",")
                dats = {}
                for x in range(0,3,2):
                    a,b = velacc[x].split(":")
                    dats[a] = b
                move_params[datno] = dats 
        return move_params
    
    def _extractFromStr(self, str, start, end):
        start_pos = 0
        end_pos = 0
        for i in range(len(str)):
            if start == str[i]:
                start_pos = i+1
            if end == str[i]:
                end_pos = i
                break
        new_str = str[start_pos:end_pos]
        return new_str

    def _extractFromSrcFile(self, dir):
        f = open(dir)
        lines = f.readlines()
        f.close()
        aqa_prg_data = {}
        aqa_points = []
        src_data = []
        for i in lines:
            i = i.replace("\n", "").strip()
            # Read PRG_Data
            if "AR_IDX_P_MAX" in i:
                if "PRG_Data" in i[0:10]:
                    line = i.split("=")[1].replace(" {","").replace("}","").replace(" , ",",").replace(", ",",").replace(" ,",",").replace(" ", ":").split(",")
                    for x in line:
                        a, b = x.split(":")
                        aqa_prg_data[a] = float(b)
            if ("PosAR[" and "{point_NR") in i:
                line = i.split("=")
                pointNo = int(self._extractFromStr(str=line[0], start="[", end="]"))
                pos = self._extractFromStr(str=line[1], start="{", end="}")
                pos = pos.replace(" ,",",").replace(", ", ",").replace(" ", ":").split(",")
                pos_dict = {"PosNo":pointNo}
                for j in pos:
                    a,b = j.split(":")
                    pos_dict[a]=float(b)
                pos_dict["speed"] = aqa_prg_data["Speed_PRG"]
                if "ueb_dis" not in i:
                    pos_dict["ueb_dis"] = aqa_prg_data["ueb_dis"]
                aqa_points.append(pos_dict)

            if ";Params" in i[0:10]:
                params = i.split(";")
                for x in params:
                    y = x.split(".")
                    if "IlfCommand" in y[0]:
                        _ , IlfCommand = y[-1].split("=")
                    if "PointName" in y[-1]:
                        _ , point = y[-1].split("=")
                    if "MoveDataName" in y[-1]:
                        _ , moveDataName = y[-1].split("=")
                    if "MoveDataPtpName" in y[-1]:
                        _ , moveDataName = y[-1].split("=")
                src_data.append({"MoveType":IlfCommand,"Point" : point, "MoveData": moveDataName})
            if ";FOLD (pre-movement before dosing Start/Dosing_ON)" in i:
                for i in aqa_points:
                    src_data.append(i)   
        return src_data

if __name__ == "__main__":
    a = ConvertKUKAPrg()
    a.kukaFileToCsv()
    pass