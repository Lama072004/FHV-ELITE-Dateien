"""
    Projekt: Roboter Bahn - Soll/Ist Visualisierung
    -   Skript zum lesen von B&R erzeugten CSV-Dateien und 
        übersetzten/portieren in standart csv-Dateien für die Visualisierung
        mit Matplotlib 

    -   convert_bur_csv erwartet den Pfad zu einer B&R CSV-Dateien und 
        gibt den Pfad zur erzeugten CSV zurück, alternativ kann über getData das 
        Pandas DataFrame direkt aus der Classe gezogen werden
    
    -   getData gibt nach dem Auslesen eines B&R CSV-Dateien die Daten als
        Pandas.DataFrame zurück 
        

    Ersteller: Böckle Markus
    Erstellt am 09.01.2025 - Aufwand ca. 2Std

    Geändert am xx.xx.xxxx - Aufwand ca. xxStd
"""

import pandas as pd
import json
import os

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))

class ConvertBurToCsv:
    def __init__(self):
        self._df = None
        self._testmode = 0
        pass
    def setTestmode(self):
        self._testmode = 1

    def getData(self):
        if isinstance(self._df, pd.DataFrame):
            return self._df
        else:
            return pd.DataFrame()
    def convert_bur_csv(self, file_dir):
        self._df = None
        self._json_read(json_file = r"source/json_file.json",)
        if self._testmode == 1:
            file_dir = os.path.join(ROOT_DIR,file_dir)
        else:
            file_dir=os.path.join(file_dir)
        
        with open(file_dir, 'r') as f:
            listLines = f.readlines()
        for i in range(len(listLines)):
            listLines[i] = listLines[i].replace("\n","")
            listLines[i] = listLines[i].replace(",",".")
            listLines[i] = listLines[i].split(";")
        append_list = []
        list_count = 0
        df = pd.DataFrame(columns=self.data["pd_headers"])
        counter = 0
        working_counter = 2000
        working_counter_act = 0
        working_print_cnt = 0
        for i in range(self.data["len_headers"],len(listLines)):
            append_list.append(listLines[i][-1])
            counter += 1
            if counter == self.data["count_params"]:
                df.loc[len(df)] = append_list
                del append_list
                counter = 0
                list_count += 1
                append_list = []
            working_counter_act += 1
            if working_counter == working_counter_act:
                working_print_cnt += 1
                working_counter_act = 0
        file_dir
        file_name = os.path.basename(file_dir)
        file_name , _ = os.path.splitext(file_name)
        dir_name = os.path.dirname(file_dir)
        file_name += self.data["export_ending"]+".csv"
        export_file = os.path.join(dir_name, file_name )
        df = df[self.data["pd_headers"]]
        df[self.data["pd_int_headers"]] = df[self.data["pd_int_headers"]].astype(int)
        df[self.data["pd_float_headers"]] = df[self.data["pd_float_headers"]].astype(float)
        self._df = df.set_index("RSI_idx")
        self._df.to_csv(export_file, sep=";")
        self._json_write(json_file = r"source/json_file.json",)
        return export_file
    def _json_read(self, *args, **kwargs):
        export_file = kwargs.get('json_file')
        file_dir = os.path.join(ROOT_DIR,export_file)
        with open(file_dir, 'r') as f:
            self.data = json.load(f)
    def _json_write(self, *args, **kwargs):
        export_file = kwargs.get('json_file')
        file_dir = os.path.join(ROOT_DIR,export_file)
        with open(file_dir, 'w') as f:
            json.dump(self.data, f, indent=4)

if __name__ == '__main__':
    a = ConvertBurToCsv()
    a.setTestmode()
    b = a.convert_bur_csv(file_dir=r"Test_Dateien\Feld_Daten\Bauteil_Korea_179\AQA_Typ002_250109_135708.csv")
    print(b)
