"""
    Projekt: Roboter Bahn - Soll/Ist Visualisierung
    -   Skript für die GUI 

    Ersteller: Böckle Markus
    Erstellt am 17.12.2024 - Aufwand ca. 4Std

    Geändert am 08.01.2025 - Aufwand ca. 2Std
    Geändert am 09.01.2025 - Aufwand ca. 4Std
    Geändert am 13.01.2025 - Aufwand ca. 2Std
"""
import os, sys

import pandas as pd

from PySide6 import QtWidgets
from PySide6.QtUiTools import QUiLoader
from PySide6.QtWidgets import QApplication,  QVBoxLayout

from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT as NavigationToolbar
import matplotlib.pyplot as plt

from ConvertKUKAPrg import ConvertKUKAPrg
from ConvertBurToCsv import ConvertBurToCsv

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))


class MyGui(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.__istData = None
        self.__sollData = None
        self._build_gui_()
        self.__gui.show()

    def _build_gui_(self, ui_file="source/main_gui.ui"):
        # Load GUI mit QUILoader
        loader = QUiLoader()
        file_dir = os.path.join(ROOT_DIR,ui_file)
        self.__gui = loader.load(file_dir)
        # Verbindungen von GUI Signalen
        self.__gui.actionIst_Daten.triggered.connect(self._importIstData_)
        self.__gui.actionSoll_Position.triggered.connect(self._importSollData_)
        self.__gui.actionSpeichern_unter.triggered.connect(self._saveAs_)
        self.__gui.actionSpeichern.triggered.connect(self._save_)
        self.__gui.actionSchlie_en.triggered.connect(self._myclose_)
        self.__gui.pushButton.clicked.connect(self._myplot_)
        # Beschriften der Labels + Buttons
        self.__gui.pushButton.setText("Plot")
        self.__gui.label_sollData_Text.setText("SOLL-Daten:")
        self.__gui.label_istData_Text.setText("IST-Daten:")
        self.__gui.label_sollData.setText(f"No Data")
        self.__gui.label_istData.setText(f"No Data")
        # Erstellen des Plotters
        self.fig = plt.figure(figsize=(24, 12))
        self.ax = self.fig.add_subplot(111, projection='3d')
        self.__mycanvas = FigureCanvas(self.fig)
        self.__Navtoolbar =  NavigationToolbar(self.__mycanvas, self)
        layout = QVBoxLayout()
        layout.addWidget(self.__Navtoolbar)
        layout.addWidget(self.__mycanvas)
        self.__gui.myPlotWidget.setLayout(layout)

    def _myplot_(self):
        self.fig.clear()
        self.ax = self.fig.add_subplot(111, projection='3d')
        if isinstance(self.__sollData,pd.DataFrame) and self.__gui.checkBox_sollData.isChecked():
            scatter = self.ax.scatter(self.__sollData["X"], self.__sollData["Y"],self.__sollData["Z"], c="red", label=f"{self.__gui.label_sollData.text()}")
            self.ax.legend(loc='upper left', bbox_to_anchor=(-0.8, 0.2)) #, fontsize='large')
        if isinstance(self.__istData,pd.DataFrame) and self.__gui.checkBox_istData.isChecked():
            scatter = self.ax.scatter(self.__istData["Path_data_X_Pos"], self.__istData["Path_data_Y_Pos"],self.__istData["Path_data_Z_Pos"], c=self.__istData["Path_data_v_path"], cmap='viridis', label=f"{self.__gui.label_istData.text()}")
            # self.fig.colorbar(scatter, ax=self.ax, shrink=0.5, aspect=5)
            cbar = self.fig.colorbar(scatter, ax=self.ax, shrink=0.5, aspect=5)
            cbar.set_label('Ist Speed (mm/sec)') 
            self.ax.legend(loc='upper left', bbox_to_anchor=(-0.8, 0.2)) #, fontsize='large')
        self.__mycanvas.draw()
    
    def _importSollData_(self):
        self.__gui.statusbar.showMessage("Import Soll-Daten", 10000)
        filePaths, _ = QtWidgets.QFileDialog.getOpenFileNames(self, 'Import Soll-Daten', ROOT_DIR,' KUKA (*.src);; Excel (*.csv )')
        fileName = os.path.basename(filePaths[0])
        filename, extens = os.path.splitext(fileName)
        self.__gui.label_sollData.setText(f"{filename}")
        if extens == ".src":
            self.__gui.statusbar.showMessage("convertiere KUKA Prg", 5000)
            a = ConvertKUKAPrg()
            a.kukaFileToCsv(dir=filePaths[0])
            self.__sollData = a.getData()
        elif extens == ".csv":
            self.__gui.statusbar.showMessage("Load csv", 5000)
            df = pd.read_csv(*filePaths, header=0,index_col=0 ,sep=";", decimal=',')
            if "Path_data_X_Pos" in df.columns:
                self.__gui.label_sollData.setText(f"CSV Datei hat ein falsches Format!")
                return
            else:
                df = pd.read_csv(*filePaths ,sep=",", decimal='.')
            df = df.replace(False, 0)
            df = df.replace(True, 1)
            df_clean = df[(df != 0).any(axis=1)]
            self.__sollData = df_clean.round(4)
            self.__gui.statusbar.showMessage("Soll-Daten importiert", 5000)
        return
    
    def _importIstData_(self):
        self.__gui.statusbar.showMessage("Import IST-Daten", 4000)
        filePaths, _ = QtWidgets.QFileDialog.getOpenFileNames(self, 'Import Ist Daten', ROOT_DIR,' Excel (*.csv )')
        fileName = os.path.basename(filePaths[0])
        self.__gui.label_istData.setText(f"{fileName}")
        df = pd.read_csv(filePaths[0], header=0,index_col=0 ,sep=";", decimal='.')
        search_string = "Path_data"
        contains_value = df.applymap(lambda x: search_string in str(x)).any().any()
        for i in df.columns:
            if search_string in i:
                contains_column = 1
                break
        if (contains_value + contains_column) < 1:
            self.__gui.statusbar.showMessage("Falsches csv Format!", 10000)
            return
        if len(df.columns) == 3:
            self.__gui.statusbar.showMessage("Convert BuR csv to DF, please wait up to 30sec", 10000)
            a = ConvertBurToCsv()
            a.convert_bur_csv(file_dir=filePaths[0])
            df = a.getData()
        self.__gui.statusbar.showMessage("Load csv", 5000)
        df = df.replace(False, 0)
        df = df.replace("false", 0)
        df = df.replace(True, 1)
        df = df.replace("true", 1)
        df_clean = df[(df != 0).any(axis=1)]
        self.__istData = df_clean.round(4)
        self.__gui.statusbar.showMessage("IST-Daten importiert", 5000)
        return
    
    def resizeEvent(self, event):
        super().resizeEvent(event)
        # Aktualisiere die Größe des Plots bei Größenänderung des Fensters
        self.__mycanvas.draw()
        return

    def _saveAs_(self, filename):
        # Vorbereitung der "Speicher als"  Funktion
        pass
    def _save_(self):
        # Vorbereitung der "Speicher" Funktion
        pass
    def _myclose_(self):
        # Vorbereitung der "Schließen" Funktion
        self.__gui.close()
        return 


if __name__ == '__main__':
    app = QApplication(sys.argv)
    run_main = MyGui()
    app.exec()