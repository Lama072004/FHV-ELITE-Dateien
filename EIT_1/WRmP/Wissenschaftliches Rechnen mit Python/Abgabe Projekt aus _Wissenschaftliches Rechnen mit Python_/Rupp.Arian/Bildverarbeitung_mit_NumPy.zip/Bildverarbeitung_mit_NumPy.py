import numpy as np
import matplotlib.pyplot as plt
import cv2                          #cv2 wird benötigt um ein image in ein Array zu konvertieren damit numpy damit arbeiten kann.

#einlesen des Bildes
chair_table = cv2.imread('chair_table.jpg')                             #cv2 ließt das Bild ein und speichert es als Array in chair_table
chair_table_rgb = cv2.cvtColor(chair_table, cv2.COLOR_BGR2RGB)      #convertierung von BGR in RGB damit plt damit arbeiten kann

#Definitionen der einzelnen Funktionen
def Heller(image, percentage):                                      #Funktion zur veräderung der Bildhelligkeit, image ist das Bild Array und percentage ist der Wert zwischen 0 und 1 in der das Bild aufgehellt werden soll
    image = image.astype(float)                                     #Typunwandlung um berechnung genauer zu machen
    brighter_image = image + (255 - image)*percentage               #Fügt dem Abstand zwischen den Pixel einen Prozentualen Teil hinzu wodurch die Farben heller werden.
    brighter_image = np.clip(brighter_image, 0, 255)                #begrenzt den Wert für den int bereich von 8 Bit, clip bewirkt das Werte unter 0 zu 0 gemacht werden und Werte über 255 zu 255
    return brighter_image.astype(np.uint8)                          #Gibt den Wert zurück, convertiert in aber wieder in 8 Bit int

def Dunkler(image, percentage):                                     #Funktion zur veräderung der Bildhelligkeit, image ist das Bild Array und percentage ist der Wert zwischen 0 und 1 in der das Bild aufgehellt werden soll 
    image = image.astype(float)                                     #Typunwandlung um berechnung genauer zu machen
    darker_image = image*(1-percentage)                             #Reduziert den Abstand zwischen den Pixel um einen Prozentualen Teil wodurch das Bild dunkler wird
    darker_image = np.clip(darker_image, 0, 255)                    #Begrenz den Wert wieder auf 8 Bit
    return darker_image.astype(np.uint8)                            #Konvertierung des Bildes wieder in 8 Bit int

def Kontrast(image, percentage):                                    #Funktion um den Kontrast zwischen den Farben zu verändern
    image = image.astype(float)                                     #Typunwandlung um berechnung genauer zu machen
    middle = np.mean(image, axis=(0, 1))                            #Mittelwertberechnung der Farben in höhe und breite
    contrasted_image = (image - middle)*percentage + middle         #Veränderungen der Farben um einen Faktor um den Mittelwert bezogen
    contrasted_image = np.clip(contrasted_image, 0, 255)            #Begrenzung der Werte auf 8 Bit
    return contrasted_image.astype(np.uint8)                        #Konvertierung des Bildes wider in 8 Bit int

def Graustufen(image):                                              #Funktion um ein Bild in Schwarzweis umzuwandeln, Wichtig dabei ist: Grauwert = 0.299⋅Rot + 0.587⋅Grun + 0.114⋅Blau, dadurch erkennt das Menschliche Auge nur Graustufen
    image = image.astype(float)                                     #Typunwandlung um die Berechnung genauer zu machen
    weighting = np.array([0.299,0.587,0.114], dtype=float)          #Festlegung der Berechungsfaktoren in einem Array
    gray_image = np.dot(image[..., :3], weighting)                  #Da Bilder 3D Arrays sind un in der dritten Dimesnion die Farben liegen muss die Berechnung genau die Farbkanäle beeinflussen; np.dot übernimmt hier die Berechnung indem er die modifizierten Farben auf die ersten zwei Kanäle aufsummiert
    return gray_image.astype(np.uint8)                              #Konvertierung in 8Bit; np.clip ist nicht notwendig, da in der Berrechnung es unmöglich ist aus dem Bereich [0,255] zu kommen

    #Erklärung zu np.dot
    #   np.dot ist eine Effiziente methode mit einer Matrix zu rechnen, 
    #   die ... bedeuten er soll alle Dimensionen mit einbeziehen die nicht
    #   explizieht erwähnt werden( in diesem Fall Höhe und Breite) und :3 
    #   bedeutet, dass er die ersten 3 Kanäle(R,G,B) der letzten Achse zur
    #   berechnung verwenden soll. np.dot nimmt immer die letzte Achese bei berechnungen

def Kantenbild(image):                                              #Kantenerkennung mithilfe des Sobel-Operators
    image = image.astype(float)                                     #Typumwandlung zur genauern berechnung
    
    #Definition Sobel-Filter in x und y Achse
    sobel_x = np.array([[-1,0,1],[-2,0,2],[-1,0,1]])                #Sobel-Filter der x-Achse; Werte sind vordefiniert
    sobel_y = np.array([[-1,-2,-1],[0,0,0],[1,2,1]])                #Sobel-Filter der y-Achse; Werte sind vordefiniert
    
    #Größe des Bildes und des Filters ermitteln
    image_height, image_width = image.shape                         #Definierung der Größe des Bildes
    kernel_height, kernel_width = sobel_x.shape                     #Definierung der Größe des Filters
    
    #Definierung eines Puffer
    puffer_x = np.zeros_like(image, dtype = np.float32)             #Erstellt einen Puffer mit zeros_like in der Form eines Null Arrays in der
    puffer_y = np.zeros_like(image, dtype = np.float32)             #größe des image Arrays wo jeder Wert die mögliche Größe von float32 hat
    
    #Randbehandlung ohne Padding
    pad_height = kernel_height // 2                                 #Verkleinert den Anwendungsbereich damit es nicht zu einem Problem kommt, da es am Rand keine Benachtbarten Pixel zum vergleichen mehr gibt
    pad_width = kernel_width // 2                                   # // ist eine Ganzzahlendivision, also keine Kommazhlen

    #Faltung für Sobel x
    for y in range(pad_height, image_height - pad_height):                                      #Schleife welcher die einzelern Zeilen nacheinander abgeht
        for x in range(pad_width, image_width - pad_width):                                     #Schleife welcher in der Zeile die einzelnen Spalten angeht
            region = image[y - pad_height:y + pad_height + 1, x - pad_width:x + pad_width + 1]  #Berechnung der abzuarbeitenden Region unter berücksichtigung des Padding
            puffer_x[y, x] = np.sum(region * sobel_x)                                           #Einspeicherung des Rechenergebnis in den Puffer

    #Faltung für Sobel y
    for y in range(pad_height, image_height - pad_height):                                      #Schleife welcher die einzelern Zeilen nacheinander abgeht
        for x in range(pad_width, image_width - pad_width):                                     #Schleife welcher in der Zeile die einzelnen Spalten angeht
            region = image[y - pad_height:y + pad_height + 1, x - pad_width:x + pad_width +1]   #Berechnung der abzuarbeitenden Region unter berücksichtigung des Padding
            puffer_y[y, x] = np.sum(region * sobel_y)                                           #Einspeicherung des Rechenergebnis in den Puffer

    
    #Kantenbild erzeugen
    edge_image = np.sqrt(puffer_x**2 + puffer_y**2)                 #Berechnung der Bildpixel mit den Puffer-Inhalten
    edge_image = np.clip(edge_image, 0, 255)                        #Begrenzung der Werte auf 8 Bit
    return edge_image.astype(np.uint8)                              #Konvertierung in 8Bit int

    
    #Erklärung zum Sobel Filter
    #   Der Sobelfilter berechnet die erste Ableitung von einem Bildpunkt-Helligkeitswert
    #   in Abhängigkeit der Pixel rundherum wobei orthogonal die Ableitungsrichtung geglättet
    #   wird. Dadurch entsteht eine Matrixstruktur in der die Pixel die zwischen zwei Helligkeitszonen
    #   liegen dargestellt werden.
    

def RGB_Modulierer(image, R, G, B):                                 #Funktion zur Modulierung der einzelnen Farbanteilen in einem Bild
    image = image.astype(float)                                     #Typumwandlung für genauere Berechnungen
    coloring = np.array([R,G,B])                                    #Array mit den Multiplikationsfaktoren für die einzelnen RGB-Bestanteile
    mod_rgb_image = image[..., :3] * coloring                       #Einmultiplikation der Faktoren in die einzelnen Farbkanäle; kein np.dot, weil das über alle Kanäle gehen würde
    mod_rgb_image = np.clip(mod_rgb_image, 0, 255)                  #Begrenzung des ergebnis auf 8 Bit
    return mod_rgb_image.astype(np.uint8)                           #Rückumwandlung der Werte in 8 Bit int
    
#Anwendung der Funktionen
brighter_chair_table_rgb = Heller(chair_table_rgb, 0.5)             #Wert zwischen 0 und 1, 0 = keine Veränderung, 1 = alles Weiß
darker_chair_table_rgb = Dunkler(chair_table_rgb, 0.5)              #Wert zwischen 0 und 1, 0 = keine Veränderung, 1 = alles Schwarz
contrasted_chair_table_rgb = Kontrast(chair_table_rgb, 2)           #Wert von 0 aufwärts, 0 = alle Farben sind gleich(kein Kontrast), 1 Kontrast ist unverändert
gray_chair_table = Graustufen(chair_table_rgb)                      #Kein zusätzlicher Wert von nöten, Grau ist Grau
edge_chair_table = Kantenbild(gray_chair_table)                     #Wichtig ist das Graubild zum Bearbeiten verwenden
mod_rgb_chair_table = RGB_Modulierer(chair_table_rgb, 2, 0.5, 0.5)  #Werte von 0 Aufwärts, in der Funktion ist ein Begrenzer eingebaut

#ploten der Bilder
plt.figure(figsize=(12,12))

#plotten des Orginalbild
plt.subplot(3,3,1)
plt.imshow(chair_table_rgb)                     #initalisierung des BIldes in unveränderter Form
plt.title("Orginal Bild")                       #Titel des Bildes
plt.axis("off")                                 #Achsen deaktivieren

#plotten mit erhöter Helligkeit
plt.subplot(3,3,2)
plt.imshow(brighter_chair_table_rgb)            #initalisierung des Bildes mit erhöter Helligkeit
plt.title("Erhoete Helligkeit")                  #Titel des Bildes
plt.axis("off")                                 #Achsen deaktivieren

#plotten mit niederer Helligkeit
plt.subplot(3,3,4)
plt.imshow(darker_chair_table_rgb)              #initialiesierung des Bildes mit verringerter Helligkeit
plt.title("Verringerte Helligkeit")             #Titel des Bildes
plt.axis("OFF")                                 #Achsen deaktiviert
 
#plotten mit verändertem Kontrast
plt.subplot(3,3,5)
plt.imshow(contrasted_chair_table_rgb)          #initaliesierung des Bildes mit verändertem Kontrast
plt.title("Veraenderter Kontrast")              #Titel des Bildes
plt.axis("OFF")                                 #Achsen deaktiviert

#plotten in Graustufen
plt.subplot(3,3,6)
plt.imshow(gray_chair_table, cmap = 'gray')     #initialisierung des BIldes in Graustufen; cmap ist wichtig da das Bild sonst mit RGB dargestellt wird
plt.title("Graustufen Bild")                    #Titel des Bildes
plt.axis("OFF")                                 #Achsen deaktiviert

#plotten des Kantenbildes
plt.subplot(3,3,7)
plt.imshow(edge_chair_table, cmap = 'gray')     #initialisierung des BIldes in Graustufen; cmap ist wichtig da das Bild sonst mit RGB dargestellt wird
plt.title("Kantenbild")                         #Titel des Bildes
plt.axis("OFF")                                 #Achsen deaktiviert

#plotten mit modulierten RGB
plt.subplot(3,3,8)
plt.imshow(mod_rgb_chair_table)                 #initialisierung des BIldes in Graustufen; cmap ist wichtig da das Bild sonst mit RGB dargestellt wird
plt.title("RGB-Moduliert")                      #Titel des Bildes
plt.axis("OFF")                                 #Achsen deaktiviert

plt.show()