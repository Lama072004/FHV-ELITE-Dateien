﻿import sympy as sp


print("Willkommen im Differentialgleichungs-Löser!")
    
#Eingabe der Ordnung der Differentialgleichung
order = int(input("Geben Sie die Ordnung der Differentialgleichung ein (z.B. 1, 2, 3): "))
    
#Definition der Variablen und Funktion
t = sp.Symbol('t')  #Input Variable, also graphische x-Achse
function_name = input("Geben Sie den Namen der Funktion ein (z.B. y): ")
f = sp.Function(function_name)  #Output Variable oder Funktionsname
    

links=0#Linke Seite der Funktion eingeben
for i in range(order + 1):
    coefficient = float(input(f"Geben Sie den Koeffizienten für die {i}. Ableitung von {function_name}(t) ein: "))
    links += coefficient * f(t).diff(t, i)
    
rechts=0#Rechte Seite der Gleichung eingeben
rechts_expr = input("Geben Sie die rechte Seite der Gleichung ein (z.B. sin(t), exp(-t)): ")
rechts = sp.sympify(rechts_expr)  #Input in mathematischen Ausdruck umwandeln, bei ungültigen Ausgaben stürzt das Programm ab
    
#Differentialgleichung definieren
differential_eq = sp.Eq(links, rechts)
#print(f"\nIhre Differentialgleichung lautet: {differential_eq}")
print(f"\nIhre Differentialgleichung lautet: {rechts}={links}")

def solve_differential_equation(differential_eq, function_name):
    

    t = sp.Symbol('t')  #Unabhängige Variable
    f = sp.Function(function_name)  #Abhängige Funktion
    
    #Lösung der Differentialgleichung
    solution = sp.dsolve(differential_eq, f(t))
    return solution

    #ausgabe = ("Die Differentialgleichung lautet: "{equation}"="{f(t)})

#Lösung berechnen
solution = solve_differential_equation(differential_eq, function_name)
print("\nLösung der Differentialgleichung:")
#print("\n"{function_name}"="{differential_eq})
print(solution)

