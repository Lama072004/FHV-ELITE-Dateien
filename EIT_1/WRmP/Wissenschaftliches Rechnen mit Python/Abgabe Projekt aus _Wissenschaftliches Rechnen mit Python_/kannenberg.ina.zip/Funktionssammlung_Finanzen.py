import numpy as np
import pandas as pd
from scipy.optimize import newton

def zinsen(amount, interest_rate):
    
    #amount= Kreditbetrag in €
    #interest_rate= Zinssatz in % p.a. (pro Jahr)  
    #return = Zinsen
    
    interestrate = interest_rate/100                
    interest_value = (amount*interestrate)/100          
    return (interest_value)



def zinseszins_effekt(amount, interest_rate, duration):
    
    #Berechnet den Zinseszins
    #amount= Anfangskapital in €
    #interest_rate= Zinssatz in %
    #duration= Periodendauer in Jahre
    #return= Endkapital nach x Jahren
    
    interestrate= interest_rate/100                      
    final_capital= amount*(1+interestrate)**duration
    return (final_capital)



def roi(initial_invest, profit_invest):
    
    #Berechnet den Return on Investment (ROI).
    #initial_invest= Anfangsinvestition
    #profit_invest= Endwert der Investition
    #return= ROI in %
    
    roi = ((profit_invest - initial_invest) / initial_invest) * 100
    return (roi)



def calculate_irr(cashflows, guess=0.1, tol=1e-6, max_iter=1000):
    
    #Berechnet den internen Zinsfuß (IRR) für eine Reihe von Cashflows mit der Newton-Raphson-Methode.
    #cashflows= Liste von Cashflows
    #guess= Anfangsschätzung für den IRR
    #tol= Toleranz für die Konvergenz
    #max_iter= Maximale Anzahl von Iterationen
    #return= IRR-Wert
    
    def npv(rate):
        return sum(cf / (1 + rate) ** i for i, cf in enumerate(cashflows))
    
    def npv_derivative(rate):
        return sum(-i * cf / (1 + rate) ** (i + 1) for i, cf in enumerate(cashflows))
    
    rate = guess
    for _ in range(max_iter):
        rate_new = rate - npv(rate) / npv_derivative(rate)
        if abs(rate_new - rate) < tol:
            return rate_new
        rate = rate_new
    
    raise ValueError("IRR konnte nicht berechnet werden. Maximale Anzahl von Iterationen erreicht.")



def amortization(loan_amount, annual_payment, interest_rate, years):
    
    #Berechnet die Amortisationsplanung für ein Darlehen.
    #loan_amount= Darlehensbetrag
    #annual_payment= Jährliche Zahlung
    #interest_rate= Zinssatz pro Jahr
    #years= Anzahl der Jahre
    #return= Liste der Restschulden nach jeder Zahlung
    
    residual_dept = loan_amount
    amortizationplan = []                              
    for year in range(1, years + 1):
        interestrate = (interest_rate/100)              
        interest = residual_dept * interestrate
        repayment = annual_payment * 12
        residual_dept -= repayment
        amortizationplan.append((year, residual_dept, repayment, interest))
    return amortizationplan