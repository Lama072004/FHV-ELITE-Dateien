import Funktionssammlung_Finanzen

 # Auswahlmenü:
def menu():
  print("""
(1) Berechnung Anfallender Zinsen
(2) Zinseszins-Effekt 
(3) Berechnung des ROI (Return of investment)
(4) Berechnung des IRR (Internal Rate of Return)
(5) Amortisationsplan""")
menu()

#Auswahl wird getroffen
choice = input("Bitte Wählen Sie: ")

#Aufrufen der Main Funktion
if __name__ == "__main__":

#if Als Auswahlhilfen, um die richtige Rechnung zu bekommen

    # Zinsen nach einem Jahr Beispiel:
    if choice == "1":
        print("\n\nBerechnen der Zinsen [in €] pro Jahr: ")

        amount = float(input("Bitte geben Sie den Kreditbetrag ein: "))
        interest_rate = float(input("Bitte Sie den Fixzins [in %] ein: "))

        zinsen = Funktionssammlung_Finanzen.zinsen (amount, interest_rate)
        print(f"\nZinsen für ein Jahr: {zinsen * 100:.2f}€ \n\n")


    # Zinseszins-Effekt Beispiel:
    if choice == "2":
        print("\n\nBeispielrechnung Zinseszins-Effekt: ")

        amount = float(input("Bitte geben Sie das Anfangskapital ein: "))
        interest_rate = float(input("Bitte gebe den Zinssatz in % ein: "))
        duration = int(input("Geben Sie die Dauer in Jahre ein: "))

        final_capital = Funktionssammlung_Finanzen.zinseszins_effekt(amount, interest_rate, duration)
        print(f"\nDas Endkapital nach {duration} Jahr(en) beträgt durch den Zinseszinseffekt: {final_capital:.2f} EUR \n\n")


    # ROI berechnen Beispiel:
    if choice == "3":
        print("\n\nBerechnen des ROI (Return of Investment): ")

        initial_invest = float(input("Bitte geben Sie Ihre Anfangsinvestition ein: "))
        profit_invest = float(input("Bitte geben Sie den Endwert der investition ein: "))

        roi_value = Funktionssammlung_Finanzen.roi(initial_invest, profit_invest)
        print(f"\nDaraus ergibt sich eine Rendite von: {roi_value:.2f}% \n\n")


    # IRR berechnen Beispiel:
    if choice == "4":
        print("\n\nBerechnen des IRR (Internal Rate of Return): ")

        cashflows = []
        print("Bitte geben Sie die Cashflows ein. Geben Sie 'fertig' ein, um die Eingabe zu beenden.")
    
        while True:
            user_input = input("Cashflow: ")
            if user_input.lower() == 'fertig':
                break
            try:
                cashflow = float(user_input)            # Die Eingabe wird in einen float umgewandelt
                cashflows.append(cashflow)              # Die EIngabe wird in der Liste cashflows gespeichert
            except ValueError:                          # ist das nicht möglich, kommt eine Fehlermeldung
                print("Ungültige Eingabe. Bitte geben Sie eine Zahl ein oder 'fertig', um die Eingabe zu beenden.")
    
        if cashflows:                                   # Wenn die Liste cashflows nciht leer ist 
            try:                                        # Wird die Funktion ausgeführt
                irr = Funktionssammlung_Finanzen.calculate_irr(cashflows)
                print(f"Der interne Zinsfuß (IRR) für die angegebenen Cashflows beträgt: {irr:.2%}")
            except ValueError as e:                     # Ist sie leer, kommt eine Fehlermeldung
                print(e)
        else:
            print("Keine Cashflows eingegeben.")


    # Amortisationsplan Beispiel:
    if choice == "5":
        print("\n\nErstellen wir einen Amortationsplan(Tilgungsplan): ")

        loan_amount = float(input("Bitte geben Sie den Darlehensbetrag an: "))
        annual_payment = float(input("Bitte geben Sie die monatliche Rückahlung ein: "))
        interest_rate = float(input("Bitte geben Sie den Zinssatz pro jahr ein: "))
        years = int(input("Bitte geben Sie die Laufzeit ein: "))

        amort_plan = Funktionssammlung_Finanzen.amortization(loan_amount, annual_payment, interest_rate, years)
        print(f"\n\nAmortisationsplan für ein Darlehen von {loan_amount} EUR:")
        print(f"{'Jahr'}   {'Restschuld'}   {'Tilgung'}   {'Zinsen'}")
        for year, residual_dept, repayment, interest in amort_plan:
            print(f"{year} {residual_dept:12.2f} {repayment:10.2f} {interest:10.2f}")     
    else: 
        print("Ungültige Eingabe, versuchen Sie es erneut")
