import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import yfinance as yf
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score


aktien_symbol = input("Bitte geben Sie das Aktien-Symbol ein: ")
start_datum = "2023-01-01"
end_datum = "2024-01-01"

aktie = yf.Ticker(aktien_symbol)
df = aktie.history(start=start_datum, end=end_datum)

df['Rendite'] = df['Close'].pct_change()
df['Volatilität'] = df['Rendite'].rolling(20).std()
df['Durchschnitt'] = df['Close'].rolling(20).mean()

if len(df) > 0:
    try:
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 10))

        df[['Close', 'Durchschnitt']].plot(ax=ax1, title=f'Aktienkursanalyse - {aktien_symbol}')
        ax1.set_ylabel('Preis in $')
        ax1.legend(['Schlusskurs', '20-Tage-Durchschnitt'])

        sns.heatmap(df[['Close', 'Rendite', 'Volatilität', 'Durchschnitt']].corr(),
                    annot=True, cmap='coolwarm', ax=ax2)
        ax2.set_title('Korrelationsmatrix')

        plt.tight_layout()
        plt.show()
    except Exception as e:
        print(f"Fehler bei der Visualisierung: {e}")

X = np.arange(len(df)).reshape(-1, 1)
y = df['Close']

if len(X) > 1:
    try:
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

        modell = LinearRegression().fit(X_train, y_train)
        vorhersage = modell.predict(X_test)

        print(f'\nAnalyse für {aktien_symbol}:')
        print(f'Aktueller Kurs: ${df["Close"].iloc[-1]:.2f}')
        print(f'Mittlerer quadratischer Fehler: {mean_squared_error(y_test, vorhersage):.2f}')
        print(f'Bestimmtheitsmaß (R²): {r2_score(y_test, vorhersage):.2f}')

        plt.figure(figsize=(10, 6))
        plt.scatter(X_test, y_test, color='blue', label='Tatsächliche Werte')
        plt.plot(X_test, vorhersage, color='red', label='Vorhersage')
        plt.legend()
        plt.title(f'Vorhersagemodell - {aktien_symbol}')
        plt.xlabel('Zeitpunkt')
        plt.ylabel('Aktienkurs in $')

        plt.ion()
        plt.show(block=True)
    except Exception as e:
        print(f"Fehler bei der Modellierung: {e}")
else:
    print("Keine Daten für die Visualisierung verfügbar.")