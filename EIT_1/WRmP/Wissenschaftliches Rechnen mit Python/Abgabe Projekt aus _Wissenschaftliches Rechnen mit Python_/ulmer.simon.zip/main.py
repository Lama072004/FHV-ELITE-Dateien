import tkinter as tk
from tkinter import ttk
import random
import time
import threading
from heapq import heappop, heappush


class AlgorithmVisualizer:
    def __init__(self, root):
        self.root = root
        self.root.title("Algorithm Visualizer")

        self.algorithm = tk.StringVar()
        self.speed = tk.DoubleVar(value=0.1)
        self.num_values = tk.IntVar(value=20)
        self.values = []
        self.running = False

        self.create_widgets()

    def create_widgets(self):
        ttk.Label(self.root, text="Select Algorithm:").pack(pady=5)
        algorithm_menu = ttk.Combobox(self.root, textvariable=self.algorithm)
        algorithm_menu['values'] = (
            "Bubble Sort", "Selection Sort", "Merge Sort", "Linear Search", "Binary Search", "Dijkstra", "A* Search")
        algorithm_menu.pack(pady=5)

        ttk.Label(self.root, text="Speed (seconds):").pack(pady=5)
        ttk.Scale(self.root, from_=0.01, to=2.0, variable=self.speed, orient='horizontal').pack(pady=5)

        ttk.Label(self.root, text="Number of Values:").pack(pady=5)
        ttk.Entry(self.root, textvariable=self.num_values).pack(pady=5)

        ttk.Button(self.root, text="Start", command=self.start_visualization).pack(pady=5)
        ttk.Button(self.root, text="Stop", command=self.stop_visualization).pack(pady=5)

        self.canvas = tk.Canvas(self.root, width=600, height=400, bg='white')
        self.canvas.pack(pady=20)

    def generate_values(self, sorted=False):
        self.values = [random.randint(1, 100) for _ in range(self.num_values.get())]
        if sorted:
            self.values.sort()
        self.draw_values()

    def draw_values(self, color_array=None):
        self.canvas.delete("all")
        canvas_width = 600
        canvas_height = 350
        bar_width = canvas_width / len(self.values)
        max_value = max(self.values)

        for i, value in enumerate(self.values):
            x0 = i * bar_width
            y0 = canvas_height - (value / max_value * canvas_height)
            x1 = (i + 1) * bar_width
            y1 = canvas_height
            color = color_array[i] if color_array else 'blue'
            self.canvas.create_rectangle(x0, y0, x1, y1, fill=color)
            self.canvas.create_text((x0 + x1) // 2, canvas_height + 5, text=str(value), anchor='n',
                                    font=('Helvetica', 10), fill='black')
        self.root.update_idletasks()

    def start_visualization(self):
        if not self.running:
            self.running = True
            thread = threading.Thread(target=self.run_algorithm)
            thread.start()

    def stop_visualization(self):
        self.running = False

    def run_algorithm(self):
        algorithm = self.algorithm.get()
        target = None

        if algorithm in ("Linear Search", "Binary Search"):
            self.generate_values(sorted=True)
            target = random.choice(self.values) if algorithm == "Linear Search" else random.choice(sorted(self.values))
            if hasattr(self, 'search_label'):
                self.search_label.config(text=f"Searching for: {target}")
            else:
                self.search_label = ttk.Label(self.root, text=f"Searching for: {target}")
                self.search_label.pack(pady=5)
        else:
            if hasattr(self, 'search_label'):
                self.search_label.pack_forget()

        if algorithm == "Bubble Sort":
            self.generate_values()
            self.bubble_sort()
        elif algorithm == "Selection Sort":
            self.generate_values()
            self.selection_sort()
        elif algorithm == "Merge Sort":
            self.generate_values()
            self.merge_sort(0, len(self.values) - 1)
        elif algorithm == "Linear Search":
            self.linear_search(target)
        elif algorithm == "Binary Search":
            self.binary_search(target)
        elif algorithm == "Dijkstra":
            self.dijkstra_pathfinding()
        elif algorithm == "A* Search":
            self.a_star_pathfinding()

        self.running = False

    def bubble_sort(self):
        n = len(self.values)
        for i in range(n):
            for j in range(n - i - 1):
                if not self.running:
                    return
                if self.values[j] > self.values[j + 1]:
                    self.values[j], self.values[j + 1] = self.values[j + 1], self.values[j]
                    self.draw_values(['red' if x == j or x == j + 1 else 'blue' for x in range(n)])
                    time.sleep(self.speed.get())
        self.draw_values(['green' for _ in range(n)])

    def selection_sort(self):
        n = len(self.values)
        for i in range(n):
            if not self.running:
                return
            min_idx = i
            for j in range(i + 1, n):
                if self.values[j] < self.values[min_idx]:
                    min_idx = j
            self.values[i], self.values[min_idx] = self.values[min_idx], self.values[i]
            self.draw_values(['green' if x == i or x == min_idx else 'blue' for x in range(n)])
            time.sleep(self.speed.get())
        self.draw_values(['green' for _ in range(n)])
        return

    def merge_sort(self, left, right):
        if left < right:
            mid = (left + right) // 2
            self.merge_sort(left, mid)
            self.merge_sort(mid + 1, right)
            self.merge(left, mid, right)
        if left == 0 and right == len(self.values) - 1:
            self.draw_values(['green' for _ in range(len(self.values))])
            return

    def merge(self, left, mid, right):
        L = self.values[left:mid + 1]
        R = self.values[mid + 1:right + 1]
        i = j = 0
        k = left
        while i < len(L) and j < len(R):
            if not self.running:
                return
            if L[i] < R[j]:
                self.values[k] = L[i]
                i += 1
            else:
                self.values[k] = R[j]
                j += 1
            k += 1
            self.draw_values(['purple' if x == k else 'blue' for x in range(len(self.values))])
            time.sleep(self.speed.get())
        while i < len(L):
            if not self.running:
                return
            self.values[k] = L[i]
            i += 1
            k += 1
        while j < len(R):
            if not self.running:
                return
            self.values[k] = R[j]
            j += 1
            k += 1

    def linear_search(self, target):
        n = len(self.values)
        for i, value in enumerate(self.values):
            if not self.running:
                return
            color_array = ['yellow' if x == i else 'blue' for x in range(n)]
            self.draw_values(color_array)
            time.sleep(self.speed.get())
            if value == target:
                self.draw_values(['green' if x == i else 'blue' for x in range(n)])
                return

    def binary_search(self, target):
        left, right = 0, len(self.values) - 1
        while left <= right:
            if not self.running:
                return
            mid = (left + right) // 2
            color_array = ['yellow' if x == mid else 'blue' for x in range(len(self.values))]
            self.draw_values(color_array)
            time.sleep(self.speed.get())
            if self.values[mid] == target:
                self.draw_values(['green' if x == mid else 'blue' for x in range(len(self.values))])
                return
            elif self.values[mid] < target:
                left = mid + 1
            else:
                right = mid - 1

    def draw_grid(self, grid, path=None, end=None):
        self.canvas.delete("all")
        rows = cols = self.num_values.get()
        cell_width = self.canvas.winfo_width() // cols
        cell_height = self.canvas.winfo_height() // rows

        for row in range(rows):
            for col in range(cols):
                color = 'white' if grid[row][col] == 0 else 'black'
                if end and (row, col) == end:
                    color = 'red'
                elif path and (row, col) in path:
                    color = 'green'
                x0, y0 = col * cell_width, row * cell_height
                x1, y1 = (col + 1) * cell_width, (row + 1) * cell_height
                self.canvas.create_rectangle(x0, y0, x1, y1, fill=color, outline='gray')
        self.root.update_idletasks()

    def find_path_dijkstra(self, grid, start, end):
        rows, cols = len(grid), len(grid[0])
        visited = set()
        heap = [(0, start)]
        came_from = {start: None}

        while heap:
            cost, current = heappop(heap)
            if current in visited:
                continue
            visited.add(current)

            if current == end:
                path = []
                while current:
                    path.append(current)
                    current = came_from[current]
                return path[::-1]

            for dr, dc in [(0, 1), (1, 0), (0, -1), (-1, 0)]:
                r, c = current[0] + dr, current[1] + dc
                if 0 <= r < rows and 0 <= c < cols and grid[r][c] == 0:
                    neighbor = (r, c)
                    if neighbor not in visited:
                        heappush(heap, (cost + 1, neighbor))
                        came_from[neighbor] = current

        return []

    def dijkstra_pathfinding(self):
        grid_size = self.num_values.get()
        self.grid = [[0 if random.random() > 0.2 else 1 for _ in range(grid_size)] for _ in range(grid_size)]

        grid = self.grid
        start, end = (0, 0), (grid_size - 1, grid_size - 1)

        path = self.find_path_dijkstra(grid, start, end)
        for step in path:
            if not self.running:
                return
            self.draw_grid(grid, path[:path.index(step) + 1], end=end)
            time.sleep(self.speed.get())

    def find_path_a_star(self, grid, start, end):
        rows = cols = self.num_values.get()
        visited = set()
        heap = [(0, start)]
        came_from = {start: None}
        g_score = {start: 0}

        def heuristic(a, b):
            return abs(a[0] - b[0]) + abs(a[1] - b[1])

        while heap:
            _, current = heappop(heap)
            if current in visited:
                continue
            visited.add(current)

            if current == end:
                path = []
                while current:
                    path.append(current)
                    current = came_from[current]
                return path[::-1]

            for dr, dc in [(0, 1), (1, 0), (0, -1), (-1, 0)]:
                r, c = current[0] + dr, current[1] + dc
                if 0 <= r < len(grid) and 0 <= c < len(grid[0]) and grid[r][c] == 0:
                    neighbor = (r, c)
                    tentative_g_score = g_score[current] + 1
                    if neighbor not in g_score or tentative_g_score < g_score[neighbor]:
                        g_score[neighbor] = tentative_g_score
                        f_score = tentative_g_score + heuristic(neighbor, end)
                        heappush(heap, (f_score, neighbor))
                        came_from[neighbor] = current

        return []

    def a_star_pathfinding(self):
        grid_size = self.num_values.get()

        self.grid = [[0 if random.random() > 0.2 else 1 for _ in range(grid_size)] for _ in range(grid_size)]

        grid = self.grid
        start, end = (0, 0), (grid_size - 1, grid_size - 1)

        path = self.find_path_a_star(grid, start, end)
        for step in path:
            if not self.running:
                return
            self.draw_grid(grid, path[:path.index(step) + 1], end=end)
            time.sleep(self.speed.get())


if __name__ == "__main__":
    root = tk.Tk()
    app = AlgorithmVisualizer(root)
    root.mainloop()
